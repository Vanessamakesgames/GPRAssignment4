﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// This script is to be attached to a GameObject called GameManager in the scene. It is to be used to manager the settings and overarching gameplay loop.
/// </summary>
public class GameManager : MonoBehaviour
{
    [Header("Scoring")]
    public int currentScore = 0; //The current score in this round.
    public int highScore = 0; //The highest score achieved either in this session or over the lifetime of the game.

    [Header("Playable Area")]
    public float levelConstraintTop; //The maximum positive Y value of the playable space.
    public float levelConstraintBottom; //The maximum negative Y value of the playable space.
    public float levelConstraintLeft; //The maximum negative X value of the playable space.
    public float levelConstraintRight; //The maximum positive X value of the playablle space.

    [Header("Gameplay Loop")]
    public bool isGameRunning; //Is the gameplay part of the game current active?
    public float totalGameTime; //The maximum amount of time or the total time avilable to the player.
    public float gameTimeRemaining; //The current elapsed time
    public GameObject player;
    public Player playerScript;
    int trackLives;

    public Slider timer;

    float playerSpawnTimer;

    int RandomNumber()
    {
        int temp = Random.Range(0, 200);
        return temp;
    }

    

    // Start is called before the first frame update
    void Start()
    {
        Instantiate(player);
        DontDestroyOnLoad(player);
        timer.minValue = 0f;
        timer.maxValue = 60f;
        timer.wholeNumbers = false;
        timer.value = timer.maxValue;
        trackLives = playerScript.playerLivesRemaining;
        playerSpawnTimer = 1.5f;
        totalGameTime = 60f;
        gameTimeRemaining = totalGameTime;
        isGameRunning = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (trackLives > playerScript.playerLivesRemaining)
        {

        }

        gameTimeRemaining -= Time.deltaTime;

        if (gameTimeRemaining <= 0)
        {
            playerScript.playerLivesRemaining--;
            //Destroy(player);
        }

        if (GameObject.FindWithTag("Player") == null)
        {
            playerSpawnTimer -= Time.deltaTime;
            if (playerSpawnTimer <= 0)
            {
                Instantiate(player);
                playerSpawnTimer = 1.5f;
            }
        }

        OnValueChange(gameTimeRemaining);

        if (playerScript.playerLivesRemaining == 0)
        {
            isGameRunning = false;
        }

        if (isGameRunning == false)
        {

        }
        //gameTimeRemaining -= Time.deltaTime;
        
    }

    public void OnValueChange(float pFloat)
    {
        timer.value = pFloat;
    }

    //public void OnValueChange(float pFloat)
    //{

    //}


}
