﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaneManager : MonoBehaviour
{
    public GameObject roadFirstLane;// = new GameObject();
    public GameObject roadSecondLaneCar;
    public GameObject roadSecondLaneTruck;
    public GameObject roadThirdLaneCar;
    public GameObject roadThirdLaneTruck;
    public GameObject roadThirdLaneBus;
    public GameObject roadFourthLaneCar;
    public GameObject roadFourthLaneTruck;
    public GameObject roadFourthLaneBus;
    public GameObject roadFifthLaneCar;
    public GameObject roadSixthLaneCar;
    public GameObject roadSixthLaneTruck;
    public GameObject roadSeventhLaneCar;
    public GameObject roadSeventhLaneTruck;
    public GameObject roadSeventhLaneBus;
    public GameObject roadEighthLaneCar;
    public GameObject roadEighthLaneTruck;
    public GameObject roadEighthLaneBus;
    public GameObject riverFirstLaneLog;
    public GameObject riverSecondLaneLog;
    public GameObject riverSecondLaneLillypad;
    public GameObject riverThirdLaneLog;
    public GameObject riverThirdLaneLillypad;
    public GameObject riverThirdLaneGator;
    public GameObject riverFourthLaneLog;
    public GameObject riverFourthLaneLillypad;
    public GameObject riverFourthLaneGator;
    //public GameObject[] roadSecondLane;// = new GameObject[2];
    //public GameObject[] roadThirdLane;// = new GameObject[3];
    //public GameObject[] roadFourthLane;// = new GameObject[3];
    //public GameObject roadFifthLane;// = new GameObject();
    //public GameObject[] roadSixthLane;// = new GameObject[2];
    //public GameObject[] roadSeventhLane;// = new GameObject[3];
    //public GameObject[] roadEighthLane;// = new GameObject[3];

    //public GameObject riverFirstLane;// = new GameObject();
    //public GameObject[] riverSecondLane;// = new GameObject[2];
    //public GameObject[] riverThirdLane;// = new GameObject[3];
    //public GameObject[] riverFourthLane;// = new GameObject[3];

    //private float[] waitTimer;
    private float l1Timer;
    private float l2Timer;
    private float l3Timer;
    private float l4Timer;
    private float l5Timer;
    private float l6Timer;
    private float l7Timer;
    private float l8Timer;
    private float l9Timer;
    private float l10Timer;
    private float l11Timer;
    private float l12Timer;
    // Start is called before the first frame update
    void Start()
    {
        //roadFirstLane = new GameObject();
        //roadSecondLane = new GameObject[2];
        //roadThirdLane = new GameObject[3];
        //roadFourthLane = new GameObject[3];
        //roadFifthLane = new GameObject();
        //roadSixthLane = new GameObject[2];
        //roadSeventhLane = new GameObject[3];
        //roadEighthLane = new GameObject[3];
        //riverFirstLane = new GameObject();
        //riverSecondLane = new GameObject[2];
        //riverThirdLane = new GameObject[3];
        //riverFourthLane = new GameObject[3];
        l1Timer = 0f;
        l2Timer = 0f;
        l3Timer = 0f;
        l4Timer = 0f;
        l5Timer = 0f;
        l6Timer = 0f;
        l7Timer = 0f;
        l8Timer = 0f;
        l9Timer = 0f;
        l10Timer = 0f;
        l11Timer = 0f;
        l12Timer = 0f;
}

    // Update is called once per frame
    void Update()
    {
        if (l1Timer <= 0) // 3 cars will be spawned at a time i the first lane
        {
            Instantiate(roadFirstLane);
            l1Timer = 1.5f;
        }
        if (l2Timer <= 0) // 3 cars will be spawned at a time i the second lane
        {
            int temp = Random.Range(0, 1);
            if (temp == 0)
            {
                Instantiate(roadSecondLaneCar);
            }
            else
            {
                Instantiate(roadSecondLaneTruck);
            }
            l2Timer = 2f;
        }
        if (l3Timer <= 0) // 3 cars will be spawned at a time i the third lane
        {
            int temp = Random.Range(0, 2);
            if (temp == 0)
            {
                Instantiate(roadThirdLaneCar);
            }
            else if (temp == 1)
            {
                Instantiate(roadThirdLaneTruck);
            }
            else
            {
                Instantiate(roadThirdLaneBus);
            }
            l3Timer = 2f;
        }
        if (l4Timer <= 0) // 3 cars will be spawned at a time i the fourth lane
        {
            int temp = Random.Range(0, 2);
            if (temp == 0)
            {
                Instantiate(roadFourthLaneCar);
            }
            else if (temp == 1)
            {
                Instantiate(roadFourthLaneTruck);
            }
            else
            {
                Instantiate(roadFourthLaneBus);
            }
            l4Timer = 1.5f;
        }
        if (l5Timer <= 0) // 3 cars will be spawned at a time i the fifth lane
        {
            Instantiate(roadFifthLaneCar);
            l5Timer = 1.5f;
        }
        if (l6Timer <= 0) // 3 cars will be spawned at a time i the sixth lane
        {
            int temp = Random.Range(0, 1);
            if (temp == 0)
            {
                Instantiate(roadSixthLaneCar);
            }
            else
            {
                Instantiate(roadSixthLaneTruck);
            }
            l6Timer = 2f;
        }
        if (l7Timer <= 0) // 3 cars will be spawned at a time i the seventh lane
        {
            int temp = Random.Range(0, 2);
            if (temp == 0)
            {
                Instantiate(roadSeventhLaneCar);
            }
            else if (temp == 1)
            {
                Instantiate(roadSeventhLaneTruck);
            }
            else
            {
                Instantiate(roadSeventhLaneBus);
            }
            l7Timer = 1.5f;
        }
        if (l8Timer <= 0) // 3 cars will be spawned at a time i the eighth lane
        {
            int temp = Random.Range(0, 2);
            if (temp == 0)
            {
                Instantiate(roadEighthLaneCar);
            }
            else if (temp == 1)
            {
                Instantiate(roadEighthLaneTruck);
            }
            else
            {
                Instantiate(roadEighthLaneBus);
            }
            l8Timer = 1.5f;
        }
        if (l9Timer <= 0) // 3 cars will be spawned at a time i the nineth lane
        {
            Instantiate(riverFirstLaneLog);
            l9Timer = 1.5f;
        }
        if (l10Timer <= 0) // 3 cars will be spawned at a time i the tenth lane
        {
            int temp = Random.Range(0, 1);
            if (temp == 0)
            {
                Instantiate(riverSecondLaneLog);
            }
            else
            {
                Instantiate(riverSecondLaneLillypad);
            }
            l10Timer = 1.5f;
        }
        if (l11Timer <= 0) // 3 cars will be spawned at a time i the eleventh lane
        {
            int temp = Random.Range(0, 2);
            if (temp == 0)
            {
                Instantiate(riverThirdLaneLog);
            }
            else if (temp == 1)
            {
                Instantiate(riverThirdLaneLillypad);
            }
            else
            {
                Instantiate(riverThirdLaneGator);
            }
            l11Timer = 1.5f;
        }
        if (l12Timer <= 0) // 3 cars will be spawned at a time i the last lane
        {
            int temp = Random.Range(0, 2);
            if (temp == 0)
            {
                Instantiate(riverFourthLaneLog);
            }
            else if (temp == 1)
            {
                Instantiate(riverFourthLaneLillypad);
            }
            else
            {
                Instantiate(riverFourthLaneGator);
            }
            l12Timer = 1.5f;
        }

        if (l1Timer > 0)
        {
            l1Timer -= Time.deltaTime;
        }
        if (l2Timer > 0)
        {
            l2Timer -= Time.deltaTime;
        }
        if (l3Timer > 0)
        {
            l3Timer -= Time.deltaTime;
        }
        if (l4Timer > 0)
        {
            l4Timer -= Time.deltaTime;
        }
        if (l5Timer > 0)
        {
            l5Timer -= Time.deltaTime;
        }
        if (l6Timer > 0)
        {
            l6Timer -= Time.deltaTime;
        }
        if (l7Timer > 0)
        {
            l7Timer -= Time.deltaTime;
        }
        if (l8Timer > 0)
        {
            l8Timer -= Time.deltaTime;
        }
        if (l9Timer > 0)
        {
            l9Timer -= Time.deltaTime;
        }
        if (l10Timer > 0)
        {
            l10Timer -= Time.deltaTime;
        }
        if (l11Timer > 0)
        {
            l11Timer -= Time.deltaTime;
        }
        if (l12Timer > 0)
        {
            l12Timer -= Time.deltaTime;
        }
    }
}
