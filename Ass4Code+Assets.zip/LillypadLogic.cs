﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LillypadLogic : MonoBehaviour
{
    public Sprite floaty, noFloaty;
    float countDown = 1f;
    // Start is called before the first frame update
    void Start()
    {
        GetComponent<SpriteRenderer>().sprite = floaty;
    }

    // Update is called once per frame
    void Update()
    {
        if (GetComponent<SpriteRenderer>().sprite == noFloaty)
        {
            GetComponent<BoxCollider2D>().enabled = false;
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            countDown -= Time.deltaTime;
            if (countDown <= 0)
            {
                GetComponent<SpriteRenderer>().sprite = noFloaty;
            }
        }
    }
}
