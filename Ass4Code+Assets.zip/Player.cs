﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor.ShortcutManagement;
using UnityEngine;

/// <summary>
/// This script must be used as the core Player script for managing the player character in the game.
/// </summary>
public class Player : MonoBehaviour
{
    public string playerName = ""; //The players name for the purpose of storing the high score
   
    public int playerTotalLives; //Players total possible lives.
    public int playerLivesRemaining; //PLayers actual lives remaining.
   
    public bool playerIsAlive = true; //Is the player currently alive?
    public bool playerCanMove = false; //Can the player currently move?
    int moveTimer = 0; // Counter to track how quickly player can move after moving
    //int posX, posY;
    float riverSpeed = 2f;

    public GameObject self;
    public GameManager myGameManager; //A reference to the GameManager in the scene.
    private Vector2 startingPosition;// = new Vector2(0f, 0.08f);
    public Sprite playerLeft, playerRight, playerUp, playerDown;
    private bool isSafe;

    //Vector2 GetPosition()
    //{
    //    return transform.position;
    //}

    // Start is called before the first frame update
    void Start()
    {
        isSafe = false;
        //myGameManager = FindObjectOfType<GameManager>();
        startingPosition = new Vector2(0f, 0.08f);
        //myGameManager.gameTimeRemaining = 60f;
        playerTotalLives = 5;
        playerLivesRemaining = playerTotalLives;
        transform.position = startingPosition;
        playerCanMove = true;
    }

    
    // Reminders:
    // Normalise units for player movement
    // Movement for player should be one normalised unit at a time

    // Update is called once per frame
    void Update()
    {
        if (playerLivesRemaining == -1)
        {
            
        }

        UpdatePosition();

        if (!playerIsAlive) // If player is not alive
        {
            if (playerLivesRemaining > 0) // If player still has lives remaining
            {
                playerLivesRemaining -= 1;
                transform.position = startingPosition;
            }
            else // Player has no lives left. Game Over
            {
                //Call Game Over, let player enter names into high scores if applicable
            }

            if (myGameManager.GetComponent<GameManager>().gameTimeRemaining <= 0)
            {
                Destroy(gameObject);
            }
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Vehicle")
        {
            Debug.Log("Hit");
            playerLivesRemaining--;
            Instantiate(self);
            Destroy(gameObject);
        }
        else if (collision.otherCollider.gameObject.tag == "Log")
        {
            if (transform.localPosition.y == 1.847 || transform.localPosition.y == 2.165) // River obstacles moving left
            {
                transform.Translate(Vector2.left * Time.deltaTime * riverSpeed * 1);
            }
            else if (transform.localPosition.y == 2.003 || transform.localPosition.y == 2.325) // River obstacles moving right
            {
                transform.Translate(Vector2.left * Time.deltaTime * riverSpeed * -1);
            }
            isSafe = true;
        }
        else if (collision.otherCollider.gameObject.tag == "Gator")
        {
            if (transform.localPosition.y == 2.165) // River obstacles moving left
            {
                transform.Translate(Vector2.left * Time.deltaTime * riverSpeed * 1);
            }
            else if (transform.localPosition.y == 2.325) // River obstacles moving right
            {
                transform.Translate(Vector2.left * Time.deltaTime * riverSpeed * -1);
            }
            isSafe = true;
        }
        else if (collision.gameObject.tag == "Lillypad")
        {
            if (transform.localPosition.y == 2.165) // River obstacles moving left
            {
                transform.Translate(Vector2.left * Time.deltaTime * riverSpeed * 1);
            }
            else if (transform.localPosition.y == 2.003 || transform.localPosition.y == 2.325) // River obstacles moving right
            {
                transform.Translate(Vector2.left * Time.deltaTime * riverSpeed * -1);
            }
            isSafe = true;
        }
        else if (collision.gameObject.tag == "Water")
        {
            if (!isSafe)
            {
                playerLivesRemaining--;
                //Instantiate(self);
                Destroy(gameObject);
            }
        }
    }

    private void CheckCollisions()
    {
        GameObject[] gameObjects = GameObject.FindGameObjectsWithTag();
    }

    void UpdatePosition()
    {
        Vector2 pos = transform.localPosition;
        if (!playerCanMove) // If player has just moved
        {
            moveTimer++;
            Debug.Log(moveTimer);
            if (moveTimer == 50)
            {
                playerCanMove = true;
                moveTimer = 0;
            }
        }

        if (playerCanMove) // If player is not dead / Has not moved within last few frames
        {
            if (Input.GetKeyDown(KeyCode.A)) // Move left
            {
                if (pos.x > -6.775999)
                {
                    // turn player to the left of screen and move in that direction
                    GetComponent<SpriteRenderer>().sprite = playerLeft;
                    pos += Vector2.left / 6.25f;
                    playerCanMove = false;
                }
            }
            if (Input.GetKeyDown(KeyCode.W)) // Move forward
            {
                // move position of sprite forwards
                GetComponent<SpriteRenderer>().sprite = playerUp;
                pos += Vector2.up / 6.25f;
                
                playerCanMove = false;
            }
            if (Input.GetKeyDown(KeyCode.S)) // Move backwards
            {
                // turn player around and move backwards
                GetComponent<SpriteRenderer>().sprite = playerDown;
                if (pos.y > -0.015)
                {
                    pos += Vector2.down / 6.25f;
                    playerCanMove = false;
                }
            }
            if (Input.GetKeyDown(KeyCode.D)) // Move right
            {
                if (pos.x < 5.991999)
                {
                    // turn player to right of screen and move in that direction
                    GetComponent<SpriteRenderer>().sprite = playerRight;
                    pos += (Vector2.right / 6.25f);
                    playerCanMove = false;
                }
            }
            transform.position = pos;
        }
    }
}
