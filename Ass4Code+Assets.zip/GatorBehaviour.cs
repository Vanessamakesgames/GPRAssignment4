﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GatorBehaviour : MonoBehaviour
{
    public Sprite chomp, stomp;
    float swapTimer = 0.5f;
    // Start is called before the first frame update
    void Start()
    {
        int temp = Random.Range(0, 1);
        if(temp == 0)
        {
            GetComponent<SpriteRenderer>().sprite = stomp;
        }
        else
        {
            GetComponent<SpriteRenderer>().sprite = chomp;
        }
    }

    // Update is called once per frame
    void Update()
    {
        swapTimer -= Time.deltaTime;

        if (swapTimer <= 0)
        {
            if (GetComponent<SpriteRenderer>().sprite == stomp)
            {
                GetComponent<SpriteRenderer>().sprite = chomp;
            }
            else
            {
                GetComponent<SpriteRenderer>().sprite = stomp;
            }
            swapTimer = 0.5f;
        }
    }

    private void OnCollisionStay(Collision collision)
    {
        if (GetComponent<SpriteRenderer>().sprite == chomp)
        {
            Destroy(collision.gameObject);
        }
    }
}
